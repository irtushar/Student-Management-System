package student_management_system;

public class Student
{
	String name;
	String mobile;
	String id;
	int year;

	public Student(String name, String mobile, String id, int year)
	{
		this.name = name;
		this.mobile = mobile;
	    this.id = id;
	    this.year = year;
	}
}
